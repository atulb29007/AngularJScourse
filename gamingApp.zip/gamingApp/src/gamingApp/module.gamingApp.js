(function (){
"use strict";

angular.module('gamingApp',['data','ui.router']);

})();
