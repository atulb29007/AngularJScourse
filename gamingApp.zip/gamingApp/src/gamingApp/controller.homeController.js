(function (){
"use strict";

angular.module('gamingApp')
.controller('homeController',homeController);

function homeController (){
  var home = this;
}

})();
